<template>
  <div class="about">
    <h1>TIM</h1>
    <p>userId: <input v-model="username" /></p>
    <button @click="handleLogin">登陆</button>
    <h3>手动发送消息</h3>
    <input type="text" v-model="msg" />
    <button @click="send">发送</button>
    <h3>接收别人发送的消息</h3>
    <ul>
      <li v-for="item in msgList" :key="item.id">发送人：{{ item.nickName }} 消息内容：{{ item.content }}</li>
    </ul>
  </div>
</template>
<script>
import genTestUserSig from '../debug/GenerateTestUserSig'
export default {
  data() {
    return {
      username: '',
      msg: '',
      msgList: [],
      isReady: false
    }
  },
  created() {
    // 登录成功，需等待 sdk 处于 ready 状态后（监听事件 TIM.EVENT.SDK_READY）才能调用 sendMessage 等需要鉴权的接口
    const onSdkReady = (event) => {
      // C2C: 单聊  GROUP：群聊  payload：载荷 里面存放我们的聊天信息  如果是文本text属性
      let message = this.tim.createTextMessage({ to: 'user1', conversationType: 'C2C', payload: { text: 'Hello world!' + Date.now() } });
      this.tim.sendMessage(message);
      this.isReady = true
    };
    this.tim.on(this.TIM.EVENT.SDK_READY, onSdkReady);

    // 接收别人发送的消息
    let onMessageReceived = (event) => {
      // 收到推送的单聊、群聊、群提示、群系统通知的新消息，可通过遍历 event.data 获取消息列表数据并渲染到页面
      // event.name - TIM.EVENT.MESSAGE_RECEIVED
      // event.data - 存储 Message 对象的数组 - [Message]
      console.log(event)
      if (event.data[0].payload.text) {
        this.msgList.push({
          id: Date.now(),
          content: event.data[0].payload.text,
          nickName: event.data[0].nick
        })
      }
    };
    this.tim.on(this.TIM.EVENT.MESSAGE_RECEIVED, onMessageReceived);
  },
  methods: {
    handleLogin() {
      // 使用自带的方法进行签名
      const userSig = genTestUserSig(this.username).userSig
      let promise = this.tim.login({ userID: this.username, userSig });
      promise.then(function (imResponse) {
        console.log(imResponse.data); // 登录成功
        if (imResponse.data.repeatLogin === true) {
          console.log(imResponse.data.errorInfo);
        }
      }).catch(function (imError) {
        console.warn('login error:', imError);
      });
    },
    send() {
      if (!this.isReady) {
        alert('IM系统还没连接')
        return
      }
      // 发送文本消息，Web 端与小程序端相同
      // 1. 创建消息实例，接口返回的实例可以上屏
      let message = this.tim.createTextMessage({ to: 'user1', conversationType: 'C2C', payload: { text: this.msg } });
      this.tim.sendMessage(message);
    }
  }
}
</script>
