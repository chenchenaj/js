<template>
  <div class="home">
    <!-- <Loading /> -->
    <button @click="show">显示</button>
    <button @click="hide">隐藏</button>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
  methods:{
    show(){
      this.$showLoading()
    },
    hide(){
      this.$hideLoading()
    }
  }
}
</script>
