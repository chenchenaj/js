import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Loading from './plugins/loading'

Vue.use(Loading)

// 从v2.11.2起，SDK 支持了 WebSocket，推荐接入；v2.10.2及以下版本，使用 HTTP
import TIM from 'tim-js-sdk';
import TIMUploadPlugin from 'tim-upload-plugin';

let options = {
  SDKAppID: 1400756141
};
let tim = TIM.create(options); // SDK 实例通常用 tim 表示

tim.setLogLevel(0); // 普通级别，日志量较多，接入时建议使用

// 注册腾讯云即时通信 IM 上传插件
tim.registerPlugin({'tim-upload-plugin': TIMUploadPlugin});
Vue.prototype.tim = tim
Vue.prototype.TIM = TIM

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
