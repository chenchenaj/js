export function genTestUserSig(userID: string): any;
export const SDKAPPID: number;
export const EXPIRETIME: number;
