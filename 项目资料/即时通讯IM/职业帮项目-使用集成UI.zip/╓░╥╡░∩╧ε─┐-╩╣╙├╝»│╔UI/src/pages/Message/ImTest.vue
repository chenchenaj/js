<template>
    <div class="wrap">
        <h1>im 自带UI集成</h1>
        <!--1. 回话列表-->
        <TUIConversation/>
        <!--2. 聊天窗口-->
        <TUIChat/>
        <!--3. 个人资料-->
        <TUIProfile/>

    </div>
</template>

<script setup lang="ts">

</script>

<style scoped lang="less">
.wrap{
    width: 100%;
    height: 100%;
}
</style>
