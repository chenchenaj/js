<template>
    <!--如果是聊天窗口  state.currentConversationID 为 true ! 为 false, showFooter false v-if ="false" -->
    <Layout :showFooter="!state.currentConversationID">
        <div class="message">
            <!--集成 im 的回话列表-->
            <main class="home-h5-main">
                <!--如果用户没有点击用户进行聊天，则 currentConversationID 为空字符串，则展示回话列表；否则展示聊天窗口-->
                <div class="message" v-show="!state.currentConversationID">
                    <main class="home-h5-content">
                        <div class="home-h5-main-content">
                            <TUIConversation @current="handleCurrentConversation"/>
                        </div>
                    </main>
                </div>
                <TUIChat v-show="state.currentConversationID"/>
            </main>
        </div>

    </Layout>
</template>

<script lang="ts" setup>
    import Layout from '../../pages/Layout/index.vue'
    import {reactive, onMounted, getCurrentInstance} from 'vue'
    import {useRoute} from 'vue-router'

    const route = useRoute();

    // const instance = getCurrentInstance(); // 返回的就是main.ts 里面的 const app = createApp(App);
    let instance = getCurrentInstance();
    const TUIKit:any = instance?.appContext.config.globalProperties.$TUIKit;

    console.log(TUIKit, 'TUIKit');


    const state = reactive({
        currentConversationID: '',
    });
    const handleCurrentConversation = (value: string) => {

        console.log(value);

        state.currentConversationID = value;
    };
    onMounted(() => {
        // 打开聊天窗口
        let companyid = route.query.companyid
        if (companyid) {
            console.log('打开聊天窗口');
            const name = `C2C${companyid}`;

            state.currentConversationID = name;
            // 如果是点击立即聊天过来的，才打开聊天窗口

            TUIKit.TUIServer.TUIConversation.getConversationProfile(name).then((imResponse: any) => {
                TUIKit.TUIServer.TUIConversation.handleCurrentConversation(imResponse.data.conversation);
            });
            return;
        }


    })


</script>

<style scoped lang="scss">
    @import "../../styles/home.scss";

    .message {
        width: 100%;
        height: 100%;

        .home-h5-main {
            height: 100%;
        }

        .top {
            height: 1.3rem;
            background-color: #139639;
            display: flex;
            align-items: center;
            padding: 0 0.3rem;

            .topTitle {
                font-size: 0.42rem;
                color: #fff;
                margin-right: 0.35rem;

            }
        }

        .content {
            width: 6.9rem;
            margin: 0 auto;
            padding: 0rem 0.3rem;
            padding-top: 0.3rem;

            .tips {
                display: flex;
                padding: 0.2rem 0.3rem;
                box-shadow: 0 0 0.36rem rgba(0, 0, 0, 0.2);
                align-items: center;
                justify-content: space-between;
                border-radius: 0.2rem;

                .tipsContent {
                    display: flex;
                    align-items: center;

                    .avatar {
                        margin-right: 0.31rem;

                        img {
                            width: 0.8rem;
                            height: 0.8rem;
                        }
                    }

                    .tipsText {
                        .title {
                            padding-bottom: 0.19rem;
                            font-size: 0.34rem;
                            font-weight: 500;
                        }

                        .text {
                            font-size: 0.24rem;
                            color: rgba(0, 0, 0, 0.5);
                        }
                    }
                }
            }

            .itemBox {
                padding: 0 0.3rem;

                .itemContent {
                    display: flex;
                    justify-content: space-between;
                    border-bottom: 0.01rem solid #e5e5e5;
                    padding: 0.32rem 0;

                    .item {
                        display: flex;
                        align-items: center;

                        .itemAvatar {
                            border-radius: 50%;
                            height: 0.8rem;
                            box-shadow: 0 0 0.36rem rgba(0, 0, 0, 0.2);
                            margin-right: 0.5rem;

                            img {
                                width: 0.8rem;
                                height: 0.8rem;
                            }
                        }

                        .itemText {
                            font-size: 0.24rem;
                            color: #999999;

                            .itemTitle {
                                color: #333333;
                                font-size: 0.34rem;
                                margin-bottom: 0.19rem;
                                width: 2rem;
                                white-space: nowrap;
                                overflow: hidden;
                                text-overflow: ellipsis;

                            }
                        }
                    }

                    .itemTime {
                        font-size: 0.18rem;
                        color: #999999;
                    }
                }

            }
        }

        .sendMsg {
            position: fixed;
            bottom: 0;
        }

    }
</style>
