import {createApp} from 'vue'
import App from './App.vue'
import './assets/less/reset.less';
import './assets/less/common.less';

const app = createApp(App);

/*集成 im */
import { TUICore, TUIComponents } from "./TUIKit";
import { genTestUserSig } from "../debug";

const config = {
    SDKAppID: 1400653563,
};
const TUIKit = TUICore.init(config);

/*TUIKit 常量就是 之前 TIM.create(config) 返回的 tim 实例对象*/
TUIKit.use(TUIComponents);

const userID = 'zhangsan';

const userInfo = {
    userID: userID,
    userSig: genTestUserSig(userID).userSig,
};
// login TUIKit
TUIKit.login(userInfo);

// register
app.use(TUIKit);



/*elementPlus UI组件库注册*/

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

app.use(ElementPlus)


/*vantUI组件库的注册*/
import Vant, {ConfigProvider} from 'vant';
import 'vant/lib/index.css';

app.use(Vant);
app.use(ConfigProvider);

/*路由注册*/
import router from './routes/index.ts';

app.use(router);

app.mount('#app')
