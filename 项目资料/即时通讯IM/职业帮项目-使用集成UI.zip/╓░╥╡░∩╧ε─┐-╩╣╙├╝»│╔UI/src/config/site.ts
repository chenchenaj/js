export const API_PREFIX = 'https://yw.52kfw.cn';
