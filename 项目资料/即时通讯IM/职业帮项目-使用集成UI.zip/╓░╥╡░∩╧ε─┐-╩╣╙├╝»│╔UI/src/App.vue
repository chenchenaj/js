<script setup lang="ts">

</script>

<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>

<style>
    #app {
        max-width: 750px;
        width: 100%;
        height: 100%;
        margin: 0 auto;
        min-width: 320px;
    }
</style>
