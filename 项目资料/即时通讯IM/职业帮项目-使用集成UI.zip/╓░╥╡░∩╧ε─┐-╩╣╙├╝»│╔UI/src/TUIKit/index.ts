import TUIComponents from './TUIComponents';
import { TUICore } from './TUICore';

export default {
  TUICore,
  TUIComponents,
};

export {
  TUICore,
  TUIComponents,
};
