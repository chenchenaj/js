const Link = {
  product: {
    label: '产品文档',
    url: 'https://cloud.tencent.com/document/product/269/1499#.E7.BE.A4.E7.BB.84.E5.8A.9F.E8.83.BD',
  },
  customMessage: {
    label: '自定义消息',
    url: 'https://web.sdk.qcloud.com/im/doc/zh-cn/SDK.html#createCustomMessage',
  },
};
export default Link;
