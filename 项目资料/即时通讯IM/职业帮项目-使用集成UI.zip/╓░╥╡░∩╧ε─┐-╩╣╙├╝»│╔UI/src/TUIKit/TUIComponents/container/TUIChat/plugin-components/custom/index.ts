import Custom from './Custom.vue';

export default Custom;
