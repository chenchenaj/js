import Image from './image.vue';

export default Image;
