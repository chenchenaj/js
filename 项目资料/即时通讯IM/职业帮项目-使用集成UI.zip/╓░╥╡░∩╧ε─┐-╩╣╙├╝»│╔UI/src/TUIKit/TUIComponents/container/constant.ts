const constant:any = {
  typeC2C: 'isC2C',
  typeGroup: 'isGroup',
  cancel: 'cancel',
  group: 'GROUP',
  at: '@',
  all: '所有人',
  typeText: 1,
  typeCustom: 2,
  typeImage: 3,
  typeAudio: 4,
  typeVideo: 5,
  typeFile: 6,
  typeFace: 8,
  typeForward: 'forward',
  typeMute: 'mute',
};

export default constant;
