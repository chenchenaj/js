import TUIProfileEdit from './index.vue';

export default TUIProfileEdit;
