import conversationList from './index.vue';

export default conversationList;
