import Location from './Location.vue';

export default Location;
