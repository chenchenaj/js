import Video from './video.vue';

export default Video;
