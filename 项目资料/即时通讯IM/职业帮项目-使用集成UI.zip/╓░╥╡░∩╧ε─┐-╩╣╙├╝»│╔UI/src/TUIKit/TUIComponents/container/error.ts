const ERROR:any = {
  80001: '您发送的消息可能包含违规内容，请停止发送此类内容',
  80002: '您发送的消息超过最大长度限制（>8KB）',
};

export default ERROR;
