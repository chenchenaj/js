import Words from './words.vue';

export default Words;
