import Manage from './manage.vue';

export {
  Manage,
};
