import File from './file.vue';

export default File;
