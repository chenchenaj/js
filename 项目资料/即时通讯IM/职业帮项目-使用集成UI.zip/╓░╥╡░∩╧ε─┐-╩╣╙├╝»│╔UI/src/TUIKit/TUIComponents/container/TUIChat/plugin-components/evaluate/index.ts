import Evaluate from './evaluate.vue';

export default Evaluate;
