import ImagePreviewer from './imagePreviewer.vue';

export default ImagePreviewer;
