const TUIUpload = '';

export default TUIUpload;
