const TUIEnv = '';

export default TUIEnv;
