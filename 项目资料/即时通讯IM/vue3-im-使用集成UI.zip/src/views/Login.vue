<template>
    <button @click="login">登陆</button>
</template>

<script lang='ts' setup>
import { genTestUserSig, EXPIRETIME } from '../../debug/index';
import { useStore } from 'vuex';
import { onBeforeMount, getCurrentInstance } from 'vue'
import { useRouter } from 'vue-router';

const instance = getCurrentInstance();
const store = useStore()
const router = useRouter()
const TUIKit: any = instance?.appContext.config.globalProperties.$TUIKit;
const login = () => {
    const userInfo = {
        userID: 'user1',
        userSig: genTestUserSig('user1').userSig,
    }
    TUIKit.login(userInfo).then((res: any) => {
        const options = {
            ...userInfo,
            expire: new Date().getTime() + EXPIRETIME * 1000,
        };
        store.commit('setUserInfo', options);
        router.push({ path: '/' });
    })
        .catch((error: any) => {
            console.log(error)
        });
}

onBeforeMount(async () => {
    if (TUIKit.isSDKReady) {
        await TUIKit.logout();
    }
});
</script>
<style lang='scss' scoped>

</style>