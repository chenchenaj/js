<template>
    <div class="home-TUIKit-main" :class="['menu' + (state.env.isH5 ? '-h5' : '')]">
        <div>
            <TUISearch class="search" />
            <TUIConversation @current="handleCurrentConversation" />
        </div>
        <div class="chat">
            <TUIChat> </TUIChat>
        </div>
    </div>
</template>
  
<script lang="ts" setup>
import { reactive, onMounted, getCurrentInstance, toRefs } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute();

// const instance = getCurrentInstance(); // 返回的就是main.ts 里面的 const app = createApp(App);
let instance = getCurrentInstance();
const TUIKit: any = instance?.appContext.config.globalProperties.$TUIKit;

console.log(TUIKit, 'TUIKit');

const state = reactive({
    currentConversationID: '',
    env: TUIKit.TUIEnv,
})

const handleCurrentConversation = (value: string) => {
    state.currentConversationID = value;
};

onMounted(() => {
    // 打开聊天窗口
    let companyid = route.query.companyid || '62a5a8fb4859f52fe4fa68f5'
    if (companyid) {
        console.log('打开聊天窗口');
        const name = `C2C${companyid}`;

        state.currentConversationID = name;
        // 如果是点击立即聊天过来的，才打开聊天窗口

        TUIKit.TUIServer.TUIConversation.getConversationProfile(name).then((imResponse: any) => {
            TUIKit.TUIServer.TUIConversation.handleCurrentConversation(imResponse.data.conversation);
        });
        return;
    }


})
</script>
  
<style scoped>
.home-TUIKit-main {
    display: flex;
    height: 100vh;
    overflow: hidden;
}

.search {
    padding: 12px;
}

.conversation {
    min-width: 285px;
    flex: 0 0 24%;
    border-right: 1px solid #f4f5f9;
}

.conversation-h5 {
    flex: 1;
    border-right: 1px solid #f4f5f9;
}

.chat {
    flex: 1;
    height: 100%;
    position: relative;
}
</style>