import TypingHeader from './typingHeader.vue';

export default TypingHeader;
