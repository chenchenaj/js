import Face from './Face.vue';

export default Face;
