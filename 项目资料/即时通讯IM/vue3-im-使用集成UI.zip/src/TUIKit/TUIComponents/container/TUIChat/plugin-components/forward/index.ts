import Forward from './forward.vue';

export default Forward;
