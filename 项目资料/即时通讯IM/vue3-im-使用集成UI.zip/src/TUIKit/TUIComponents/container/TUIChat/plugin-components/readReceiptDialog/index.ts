import ReadReceiptDialog from './readReceiptDialog.vue';

export default ReadReceiptDialog;
