import Dialog from './index.vue';

export default Dialog;
