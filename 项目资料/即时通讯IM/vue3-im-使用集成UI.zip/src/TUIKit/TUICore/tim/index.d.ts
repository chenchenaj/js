export default TIM;
