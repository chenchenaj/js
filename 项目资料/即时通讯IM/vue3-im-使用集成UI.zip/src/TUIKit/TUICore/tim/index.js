import TIM from 'tim-js-sdk/tim-js-friendship.js';

export default TIM;
