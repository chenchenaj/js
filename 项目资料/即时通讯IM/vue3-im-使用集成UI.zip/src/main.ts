import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';

// import TIM from "tim-js-sdk";

import { SDKAPPID } from '../debug';

import { TUICore, TUIComponents } from './TUIKit';

const config = {
  SDKAppID: SDKAPPID,
};

const TUIKit = TUICore.init(config);

TUIComponents.TUIChat.removePluginComponents(['Custom', 'Location']);

// 方法二: 全部挂载
TUIKit.use(TUIComponents);

const app = createApp(App);


app
  .use(store)
  .use(router)
  .use(TUIKit)
  .mount('#app');
