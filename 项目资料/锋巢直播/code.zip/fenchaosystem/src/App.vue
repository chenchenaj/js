<template>
  <el-container>
    <el-header>
      <el-page-header
        content="直播带货后台系统"
        icon=""
        title="简易版"
      />
    </el-header>
    <el-main>

      <el-select
        v-model="selected"
        class="m-2"
        placeholder="Select"
        size="large"
      >
        <el-option
          v-for="item in options"
          :key="item.im_id"
          :label="item.room_name"
          :value="item.im_id"
        >
        </el-option>
      </el-select>

      <el-button
        type="danger"
        @click="handleUpload"
      >上架商品</el-button>
      <el-button
        type="primary"
        @click="isAddVisible = true"
      >添加商品</el-button>
      <!-- {{form}} -->
      <el-table
        :data="tableData"
        style="width: 100%"
      >
        <el-table-column
          prop="name"
          label="商品名称"
        />
        <el-table-column
          prop="price"
          label="商品价格"
        />

        <el-table-column label="操作">
          <template #default="scope">
            <el-button
              size="small"
              @click="handleEdit(scope.row)"
            >更新</el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete( scope.row)"
            >删除</el-button>
          </template>

        </el-table-column>

      </el-table>

      <!-- 添加商品的弹出框 -->
      <el-dialog
        v-model="isAddVisible"
        title="添加商品"
      >
        <el-form
          :model="addform"
          :rules="addrules"
          ref="addFormRef"
        >
          <el-form-item
            label="商品名称"
            prop="name"
          >
            <el-input
              v-model="addform.name"
              autocomplete="off"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="商品价格"
            prop="price"
          >
            <el-input
              type="number"
              v-model="addform.price"
              autocomplete="off"
            ></el-input>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="isAddVisible = false">取消</el-button>
            <el-button
              type="primary"
              @click="handleAddConfirm"
            >确认</el-button>
          </span>
        </template>
      </el-dialog>

      <!-- 更新商品的弹出框 -->
      <el-dialog
        v-model="isEditVisible"
        title="更新商品"
      >
        <el-form
          :model="editform"
          :rules="editrules"
          ref="editFormRef"
        >
          <el-form-item
            label="商品名称"
            prop="name"
          >
            <el-input
              v-model="editform.name"
              autocomplete="off"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="商品价格"
            prop="price"
          >
            <el-input
              type="number"
              v-model="editform.price"
              autocomplete="off"
            ></el-input>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="isEditVisible = false">取消</el-button>
            <el-button
              type="primary"
              @click="handleEditConfirm"
            >确认</el-button>
          </span>
        </template>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script setup>
import useTable from "./hooks/useTable.js";
import useAddForm from "./hooks/useAddForm.js";
import useEditForm from "./hooks/useEditForm.js";
import useSelect from "./hooks/useSelect.js";
import { ElLoading,ElMessage } from "element-plus";

import axios from "axios";
let loading = null;
axios.interceptors.request.use(
  function(config) {
    // Do something before request is sent
    loading = ElLoading.service({
      lock: true,
      text: "Loading",
      background: "rgba(0, 0, 0, 0.7)"
    });
    return config;
  },
  function(error) {
    // Do something with request error
    return Promise.reject(error);
  }
);

// Add a response interceptor
axios.interceptors.response.use(
  function(response) {
    loading.close();
    return response;
  },
  function(error) {
    loading.close();
    return Promise.reject(error);
  }
);

const showEditForm = item => {
  isEditVisible.value = true;
  // console.log(item)
  editform.value = item;
};

const hideEditForm = () => {
  isEditVisible.value = false;
};

const { tableData, refreshTable, handleEdit, handleDelete } = useTable(
  showEditForm,
  hideEditForm
);
const {
  isAddVisible,
  addform,
  addrules,
  addFormRef,
  handleAddConfirm
} = useAddForm(refreshTable);
const {
  isEditVisible,
  editform,
  editrules,
  editFormRef,
  handleEditConfirm
} = useEditForm(refreshTable);

const { selected, options } = useSelect();

const handleUpload = () => {
  axios
    .post("/api/uploadGood", {
      GroupId: selected.value,
      data: tableData.value
    })
    .then(() => {
      ElMessage({
        message: "上架商品成功",
        type: "success"
      });
    });
};
</script>

<style>
</style>
