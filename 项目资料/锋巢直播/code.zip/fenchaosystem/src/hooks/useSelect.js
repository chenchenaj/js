/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import {ref,onMounted} from 'vue'
import axios from 'axios'
function useSelect(){
    const selected = ref("")
    const options = ref([])
    onMounted(()=>{
        axios.get("/api/getRoomList").then(res=>{
            // console.log()

            options.value = res.data.rooms.filter(item=>item.room_status)
        })
    })
    return {
        selected,
        options
    }
}

export default useSelect