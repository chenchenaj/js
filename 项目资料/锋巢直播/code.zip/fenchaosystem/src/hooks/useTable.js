/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import {ref,onMounted} from 'vue'
import axios from 'axios'
function useTable(showEditForm){
    const tableData = ref([])
    onMounted(()=>{
        refreshTable()
    })

    const refreshTable = ()=>{
        axios.get("/api/getGood").then(res=>{
            // console.log(res.data)
            tableData.value=  res.data.list
        })
    }

    const handleEdit = (item)=>{
        // console.log(item)
        showEditForm(item)
    }

    const handleDelete =(item)=>{
        console.log(item)
        axios.post("/api/deleteGood",{
            ...item
        }).then(()=>{
            refreshTable()
        })
    }
    return {
        tableData,
        refreshTable,
        handleEdit,
        handleDelete
    }
}

export default useTable