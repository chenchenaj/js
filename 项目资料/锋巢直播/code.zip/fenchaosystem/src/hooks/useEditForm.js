/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import { ref, reactive } from 'vue'
import axios from 'axios'
function useEditForm(refreshTable) {

    const isEditVisible = ref(false)
    const editFormRef =  ref()

    const editform = ref({
        name: '',
        price: 0
    })
    const editrules = reactive({
        name: [
            {
                required: true,
                message: '请输入名字',
                trigger: 'blur',
            }
        ],
        price: [
            {
                required: true,
                message: '请输入价格',
                trigger: 'blur',
            }
        ]

    })

    const handleEditConfirm = ()=>{
        editFormRef.value.validate((valid) => {
            if (valid) {
            //   console.log('submit!',editform.value)
                axios.post("/api/updateGood",{
                    ...editform.value
                }).then(res=>{
                    if(res.data.ActionStatus==="OK"){
                        isEditVisible.value= false

                        //更新列表-todo

                        refreshTable()
                    }
                })
            } else {
              console.log('error submit!')
              return false
            }
        })
          
    }
    return {
        isEditVisible,
        editform,
        editrules,
        editFormRef,
        handleEditConfirm
    }
}

export default useEditForm