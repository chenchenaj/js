/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import { ref, reactive } from 'vue'
import axios from 'axios'
function useAddForm(refreshTable) {

    const isAddVisible = ref(false)
    const addFormRef =  ref()

    const addform = reactive({
        name: '',
        price: 0
    })

    const addrules = reactive({
        name: [
            {
                required: true,
                message: '请输入名字',
                trigger: 'blur',
            }
        ],
        price: [
            {
                required: true,
                message: '请输入价格',
                trigger: 'blur',
            }
        ]

    })

    const handleAddConfirm = ()=>{
        addFormRef.value.validate((valid) => {
            if (valid) {
            //   console.log('submit!',addform)
                axios.post("/api/addGood",{
                    ...addform
                }).then(res=>{
                    // console.log(res.data.ActionStatus)
                    if(res.data.ActionStatus==="OK"){
                        isAddVisible.value= false

                        //更新列表-todo

                        refreshTable()
                    }
                })
            } else {
              console.log('error submit!')
              return false
            }
        })
        
    }
    return {
        isAddVisible,
        addform,
        addrules,
        addFormRef,
        handleAddConfirm
    }
}

export default useAddForm