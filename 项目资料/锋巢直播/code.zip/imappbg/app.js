const express = require('express')
const app = express()
const bodyParser = require("body-parser")
const wxRegister= require("./api/wxRegister")
const createGroup= require("./api/createGroup")
const getUser= require("./api/getUser")
const getRoomList= require("./api/getRoomList")
const getUserSig= require("./api/getUserSig")
const like= require("./api/like")
const sendGift= require("./api/sendGift")
const follow= require("./api/follow")
const unfollow= require("./api/unfollow")
const getUserInfo= require("./api/getUserInfo")
const getGiftList = require('./api/getGiftList')
const buyGoods = require('./api/buyGoods')
const changeRoomStatus = require('./api/changeRoomStatus')

/*后台系统的接口*/
const good  = require('./api/good')
const port = 9000

app.use(express.static("public"))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:false}))

app.get('/', (req, res) => {
  res.send('Hello World!')
})

//注册路由
app.post("/wxRegister",wxRegister)
app.post("/createGroup",createGroup)
app.post("/getUser",getUser)
app.get("/getRoomList",getRoomList)
app.get("/getUserSig",getUserSig)
app.post("/like",like)
app.post("/sendgift",sendGift)
app.post("/follow",follow)
app.post("/unfollow",unfollow)
app.post("/getUserInfo",getUserInfo)
app.post("/getGiftList",getGiftList)
app.post("/buyGoods",buyGoods)
app.post("/changeRoomStatus",changeRoomStatus)

/*后台系统的接口*/
app.post("/api/addGood",good.addGood)
app.get("/api/getGood",good.getGood)
app.post("/api/updateGood",good.updateGood)
app.post("/api/deleteGood",good.deleteGood)
app.get("/api/getRoomList",getRoomList)
app.post("/api/uploadGood",good.uploadGood)


app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})