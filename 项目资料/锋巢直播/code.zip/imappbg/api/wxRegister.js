/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const { default: axios } = require("axios")
const mysql2 = require("mysql2")
const apiUserSig = require('../util/userSig')
 
const getUserSig  = function(userId){
    const sig = new apiUserSig.Api(1400637478,"168e17eff1c864ddbf62cd6af495b89a1d0b923448d1280fad44f596c809c946")
    const userSig = sig.genSig(userId,60*24*60*60)
    return userSig
}


// console.log(userSig)

 async function wxRegister(req,res){

    // console.log(req.body)
    const {userInfo,code}  = req.body
    const result = await axios.get(`https://api.weixin.qq.com/sns/jscode2session?appid=wx10456260aac4c19e&secret=d592a559a95193a3dfe69fc1720449dd&js_code=${code}&grant_type=authorization_code`) 
    console.log(result.data.openid)

    const userSig = getUserSig("administrator")
    const imObj = await axios.post(`https://console.tim.qq.com/v4/im_open_login_svc/account_import?sdkappid=1400637478&identifier=administrator&usersig=${userSig}&random=${Math.random()}&contenttype=json`,{
        "UserID":result.data.openid,
        "Nick":userInfo.nickName,
        "FaceUrl":userInfo.avatarUrl
     }
     )
    //  console.log(imObj)

    if(imObj.data.ActionStatus!=="OK"){
        res.send({
            code:imObj.data.ErrorCode,
            msg:"添加IM账号体系用户出错了"
        })
        return
    }

    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    await promisePool.query('insert into users (id, nick,gender, avatar,create_time) values (?,?,?,?,?)',[
        result.data.openid,
        userInfo.nickName,
        userInfo.gender,
        userInfo.avatarUrl, 
        new Date()
    ])

    res.send({
        id:result.data.openid,
        ActionStatus:"OK"
    })
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = wxRegister