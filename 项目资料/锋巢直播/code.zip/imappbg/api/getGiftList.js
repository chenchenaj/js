/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const mysql2 = require("mysql2")


// console.log(userSig)

 async function getGiftList(req,res){

    console.log(req.body)
    const {to_id} = req.body
    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    const [giftlist]  =await promisePool.query(`
    select
       send_gift.id,send_gift.from_id,send_gift.gift_id,

       users.nick,users.avatar
    from send_gift
    left join users on users.id=send_gift.from_id

    where send_gift.to_id="${to_id}"

    order by send_gift.create_time desc limit 100
    `)

    res.send({
        giftlist:giftlist,
        ActionStatus:"OK"
    })
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = getGiftList