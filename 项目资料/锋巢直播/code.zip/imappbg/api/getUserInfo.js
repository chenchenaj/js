/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const mysql2 = require("mysql2")


// console.log(userSig)

 async function getUserInfo(req,res){

    console.log(req.body)
    const {from_id,to_id} = req.body
    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    const [followsData] = await promisePool.query(`select id  from  follows where from_id="${from_id}" and to_id="${to_id}"` )
    const [[followobj]] = await promisePool.query(`select count(*) as count  from  follows where to_id="${to_id}"` )

    const [[likes]] = await promisePool.query(`select count(*) as count  from  likes where to_id="${to_id}"` )

    const [[gifts]] = await promisePool.query(`select count(*) as count  from  send_gift where to_id="${to_id}"` )
    // [[1,2],{}]

    // console.log(res1)
    res.send({
        fans:followobj.count,
        like:likes.count,
        gift:gifts.count,
        isFollowed:followsData.length?true:false,
        ActionStatus:"OK"
    })
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = getUserInfo