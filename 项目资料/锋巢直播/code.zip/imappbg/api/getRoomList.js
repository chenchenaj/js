/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const { default: axios } = require("axios")
const mysql2 = require("mysql2")


// console.log(userSig)

 async function getRoomList(req,res){

    // console.log(req.body
    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    let rooms = await promisePool.query('select * from rooms')

    console.log(rooms[0])

    if(rooms[0].length ===0) {
        res.send({
            code:-2,
            msg:"room is empty"
        })
    }else{
        res.send({
            rooms:rooms[0],
            ActionStatus:"OK"
        })
    }
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = getRoomList