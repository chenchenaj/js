/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const { default: axios } = require("axios")
const mysql2 = require("mysql2")


// console.log(userSig)

 async function getUser(req,res){

    // console.log(req.body)
    const {code}  = req.body
    const result = await axios.get(`https://api.weixin.qq.com/sns/jscode2session?appid=wx10456260aac4c19e&secret=d592a559a95193a3dfe69fc1720449dd&js_code=${code}&grant_type=authorization_code`) 
    console.log(result.data.openid)


    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    let users = await promisePool.query('select * from users where id = ?',[
        result.data.openid
    ])

    console.log(users[0])

    if(users[0].length ===0) {
        res.send({
            code:-2,
            msg:"user not exist",
            openid:result.data.openid
        })
    }else{
        res.send({
            user:users[0][0],
            ActionStatus:"OK"
        })
    }
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = getUser