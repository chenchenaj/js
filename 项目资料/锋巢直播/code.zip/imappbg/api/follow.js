/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const mysql2 = require("mysql2")


// console.log(userSig)

 async function follow(req,res){

    console.log(req.body)
    const {from_id,to_id} = req.body
    //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    await promisePool.query('insert into follows (id,from_id,to_id,create_time) values (?,?,?,?)' ,[
        null,
        from_id,
        to_id,
        new Date()
    ])

    res.send({
        ActionStatus:"OK"
    })
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = follow