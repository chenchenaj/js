/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const apiUserSig = require('../util/userSig')
 
const getUserSig  = function(userId){
    const sig = new apiUserSig.Api(1400637478,"168e17eff1c864ddbf62cd6af495b89a1d0b923448d1280fad44f596c809c946")
    const userSig = sig.genSig(userId,60*24*60*60)
    return userSig
}


// console.log(userSig)

 async function getUserSigFunc(req,res){

    // console.log(req.body)
    const {userID}  = req.query

    const userSig = getUserSig(userID)
    
    res.send({
        userSig,
        sdkID:1400637478,
        ActionStatus:"OK"
    })
 }


 module.exports = getUserSigFunc