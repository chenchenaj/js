/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */

const { default: axios } = require("axios")
const mysql2 = require("mysql2")
const apiUserSig = require('../util/userSig')
 
const getUserSig  = function(userId){
    const sig = new apiUserSig.Api(1400637478,"168e17eff1c864ddbf62cd6af495b89a1d0b923448d1280fad44f596c809c946")
    const userSig = sig.genSig(userId,60*24*60*60)
    return userSig
}


// console.log(userSig)

 async function createGroup(req,res){

    console.log(req.body)
    const {userInfo,id}  = req.body

    const userSig = getUserSig("administrator")
    const imObj = await axios.post(`https://console.tim.qq.com/v4/group_open_http_svc/create_group?sdkappid=1400637478&identifier=administrator&usersig=${userSig}&random=${Math.random()}&contenttype=json`,{
        "Owner_Account": id,  //群主id
        "GroupId": id,  //群组id
        "Type": "AVChatRoom", 
        "Name": userInfo.nickName,
        "Introduction": `大家好，我是${userInfo.nickName}`, // 群简介（选填）
        "Notification": "请大家文明发言", // 群公告（选填）
    }
     )
    //  console.log(imObj)

    if(imObj.data.ActionStatus!=="OK"){
        res.send({
            code:imObj.data.ErrorCode,
            msg:"创建群组出错"
        })
        return
    }

    // //存入数据库
    const config = getDBConfig()
    const promisePool = await mysql2.createPool(config).promise()

    await promisePool.query('insert into rooms (id, im_id,room_name, room_desc,room_owner,room_cover,room_push_link,room_play_link,room_status) values (?,?,?,?,?,?,?,?,?)',[
        null,
        id,
        userInfo.nickName,
        `大家好，我是${userInfo.nickName}`,
        id,
        userInfo.avatarUrl,
        `rtmp://161847.livepush.myqcloud.com/live/${id}`, 
        `http://aaa.raink.net/live/${id}.flv`,
        1
    ])

    res.send({
        im_id:id,
        ActionStatus:"OK"
    })
 }

 function getDBConfig(){
    return {
        host:"bj-cdb-7iq1bdfo.sql.tencentcdb.com",
        port:60074,
        user:"root",
        password:"1qazxsw2",
        database:"kerwin_test",
        connectionLimit:1
    }
 }

 module.exports = createGroup